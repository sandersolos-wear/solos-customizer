import CanvasDemo from "@/components/CanvasDemo";

export default function AppBlock() {
  return (
    <div style={{ maxWidth: 600, margin: "0 auto" }}>
      <h3>Solos Customizer (MVP)</h3>
      <CanvasDemo />
      {/* TODO: upload, tekst, DPI-check, export knoppen */}
    </div>
  );
}
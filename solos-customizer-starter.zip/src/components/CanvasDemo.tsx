import { useEffect, useRef } from "react";
import { fabric } from "fabric";

export default function CanvasDemo() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    const canvas = new fabric.Canvas(ref.current, { backgroundColor: "#f7f7f7" });
    const safe = new fabric.Rect({ left: 50, top: 50, width: 300, height: 300, stroke: "red", fill: "", strokeDashArray: [5, 5] });
    canvas.add(safe);
    return () => canvas.dispose();
  }, []);
  return <canvas ref={ref} width={500} height={500} />;
}
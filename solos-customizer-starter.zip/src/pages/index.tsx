import { AppProvider, Page, Card, Text } from "@shopify/polaris";

export default function Home() {
  return (
    <AppProvider i18n={{}}>
      <Page title="Solos Customizer">
        <Card sectioned>
          <Text as="p">De app is geïnstalleerd. Plaats het App Block op een productpagina om de Customizer te tonen.</Text>
        </Card>
      </Page>
    </AppProvider>
  );
}
import type { NextApiRequest, NextApiResponse } from "next";
import { generatePrintTicket } from "@/lib/pdf";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).end();
  const { orderId = "TEST-ORDER", sku = "TEST-SKU", position = "chest_left", sizeCm = "10x10" } = req.body || {};
  const doc = generatePrintTicket({ orderId, sku, position, sizeCm });
  res.setHeader("Content-Type", "application/pdf");
  doc.pipe(res);
}
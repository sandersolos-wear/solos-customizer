import type { NextApiRequest, NextApiResponse } from "next";
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // TODO: verify HMAC, parse order, attach files via Admin API
  console.log("Order webhook ontvangen", req.body?.id);
  res.status(200).json({ ok: true });
}
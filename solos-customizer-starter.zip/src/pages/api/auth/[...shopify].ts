import type { NextApiRequest, NextApiResponse } from "next";
import { shopify } from "@/lib/shopify";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === "GET") {
    const { searchParams } = new URL(req.url!, process.env.SHOPIFY_APP_URL);
    const shop = searchParams.get("shop") || process.env.SHOPIFY_SHOP!;
    const authBegin = await (shopify as any).auth.begin({
      shop,
      callbackPath: "/api/auth/[...shopify]",
      isOnline: true,
      rawRequest: req,
      rawResponse: res,
    });
    return authBegin;
  }
  if (req.method === "POST") {
    const result = await (shopify as any).auth.callback({ rawRequest: req, rawResponse: res });
    await (shopify as any).session.storage.storeSession(result.session);
    return res.redirect(302, "/");
  }
  res.status(405).end();
}
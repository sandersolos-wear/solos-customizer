export async function saveDesignPng(_buf: Buffer, _name: string) {
  // TODO: upload to Shopify Files or S3
  return { url: `/placeholder/${_name}` };
}
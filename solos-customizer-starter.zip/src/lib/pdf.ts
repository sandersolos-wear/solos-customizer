import PDFDocument from "pdfkit";

export function generatePrintTicket(data: {
  orderId: string; sku: string; position: string; sizeCm: string;
}) {
  const doc = new PDFDocument({ size: "A4", margin: 36 });
  doc.fontSize(16).text("Solos Wear — Printticket", { align: "left" });
  doc.moveDown();
  doc.fontSize(12).text(`Order: ${data.orderId}`);
  doc.text(`SKU: ${data.sku}`);
  doc.text(`Positie: ${data.position}`);
  doc.text(`Formaat: ${data.sizeCm}`);
  doc.end();
  return doc;
}
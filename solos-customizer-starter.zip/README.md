# Solos Customizer (MVP)

## Snel starten
1. Kopieer `.env.example` naar `.env.local` en vul variabelen in.
2. `npm i && npm run dev`
3. Ga naar `/` (embedded admin) en `/appblock` (Customizer placeholder).

## Deploy (Vercel)
- Zet alle .env variabelen in Vercel.
- App URL/redirects in Shopify aanpassen naar je Vercel URL.

## Volgende stappen
- Upload/tekst tools toevoegen aan `CanvasDemo`.
- PNG/Proof export in `/api/export` uitleveren & koppelen aan order.
- Webhook `order/create` verwerken en bestanden als order-bijlagen plaatsen.
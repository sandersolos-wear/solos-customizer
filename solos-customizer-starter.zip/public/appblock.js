(function(){
  const mount = document.currentScript?.parentElement || document.body;
  const iframe = document.createElement('iframe');
  iframe.src = '/appblock';
  iframe.style.width = '100%';
  iframe.style.border = '0';
  iframe.onload = () => { iframe.style.height = '700px'; };
  mount.appendChild(iframe);
})();
import type { NextApiRequest, NextApiResponse } from "next";
import { shopify } from "@/lib/shopify";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "GET") return res.status(405).end();
  const shopParam = (req.query.shop as string) || process.env.SHOPIFY_SHOP!;
  // Start OAuth
  await (shopify as any).auth.begin({
    shop: shopParam,
    callbackPath: "/api/auth/callback",
    isOnline: true,
    rawRequest: req,
    rawResponse: res,
  });
}
import type { NextApiRequest, NextApiResponse } from "next";
import { shopify } from "@/lib/shopify";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "GET" && req.method !== "POST") return res.status(405).end();
  // Complete OAuth
  const result = await (shopify as any).auth.callback({ rawRequest: req, rawResponse: res });
  await (shopify as any).session.storage.storeSession(result.session);
  // Redirect to embedded admin home
  res.redirect(302, "/");
}